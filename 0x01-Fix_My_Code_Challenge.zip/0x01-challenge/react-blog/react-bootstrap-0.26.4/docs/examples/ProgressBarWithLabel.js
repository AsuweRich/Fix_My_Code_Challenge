const progressInstance = (
  <ProgressBar now={60} label="%(percent)s%" />
);

React.render(progressInstance, mountNode);
