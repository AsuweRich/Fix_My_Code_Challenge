const alertInstance = (
  <Alert bsStyle="warning">
    <strong>Holy guacamole!</strong> Best check yo self, you're not looking too good.
  </Alert>
);

React.render(alertInstance, mountNode);
