const buttonGroupInstance = (
  <ButtonGroup vertical block>
    <Button>Full width button</Button>
    <Button>Full width button</Button>
  </ButtonGroup>
);

React.render(buttonGroupInstance, mountNode);
